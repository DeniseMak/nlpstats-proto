

# System Performance Report

## Data Analysis

Tests indicate the following about the data in the file `score`:
  * 3
  * 3
  * 3


Based on this information, the following significance tests are appropriate for your data:

3

## Significance testing

Requiring a significance level $\alpha = 3$, 3 iterations for bootstraping tests, and an expected mean difference for null hypothesis mean of 3 and using the 3 significance test, we can conclude that you 3 the null hypothesis. The test statistic and confidence interval are 3 respectively.

## Effect Size

## Power Analysis



